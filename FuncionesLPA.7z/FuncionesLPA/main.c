#include <stdio.h>
#include <stdlib.h>


/*devuelve cualqier entero,
si se pide edad por ejemplo el mensaje dice " ingrese edad" es decir muestra un mensaje que le pase

max y min, se lo pide, si no ingresa en esos valores muestra el MENSAJE DE error

intentos
*/
int getInt(char mensaje[], char mensajeError[],int intentos, int maximo, int minimo);
void saludar(void);

int main()
{
    saludar();
    getInt("INGRESE SU EDAD: ","SU EDAD ES INVALIDA \n",5,100,1);
   return 0;
}

void(char saludar[])
{
    printf()
}

int getInt(char mensaje[], char mensajeError[],int intentos, int maximo, int minimo)
{
    int retorno;
       do{
        printf("%s",mensaje);
        scanf("%d",&retorno);
        if(retorno<=maximo && retorno>=minimo)
        {
          break;
        }
        printf("%s",mensajeError);
        intentos--;
    }while(intentos>0);

       return retorno; // completar el return
}
